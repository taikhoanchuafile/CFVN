﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SieuThiSach.Areas.Admin.Controllers
{
    public class QuanLyQuangCaoController : Controller
    {
        //
        // GET: /Admin/QuangCao/
        public ActionResult Index()
        {
            return View();
        }
	}
}